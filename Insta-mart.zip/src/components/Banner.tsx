import { TruckIcon, XIcon, ZapIcon } from "lucide-react";
import { useState } from "react";

const Banner = () => {
  const [bannerVisible, setBannerVisible] = useState(() => {
    return sessionStorage.getItem("banner_dismissed") !== "true";
  });

  const dismissBanner = () => {
    setBannerVisible(false);
    sessionStorage.setItem("banner_dismissed", "true");
  };

  return (
    <div>
      {bannerVisible && (
        <div className="bg-linear-to-r from-app-green via-emerald-800 to-app-green text-white text-xs sm:text-sm relative overflow-hidden">
          {/*  ===== */}
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8 py-2 flex items-center justify-center gap-6">
            {/* // nested div 2 */}
            <div className="flex items-center gap-2 text-center">
              <TruckIcon className="size-8 shrink-0" />
              <span className="font-semibold text-2xl">
                Free Delivery on orders above $20
              </span>
            </div>
            <span className="hidden sm:inline text-white/40"></span>
            <div className="hidden sm:flex items-center gap-2 text-2xl">
              <ZapIcon className="size-6.5 fill-yellow-400 text-yellow-400 shrink-0" />
              <span>Farm-Fresh produce delivered daily</span>
            </div>
          </div>

          <button
            onClick={dismissBanner}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1 hover:bg-white/10 rounded-full transition-colors"
          >
            <XIcon className="size-5 text-black" />
          </button>
        </div>
      )}
    </div>
  );
};

export default Banner;

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

interface Product {
  id: string;
  name: string;
  price: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {

    const [items, setItems] = useState<CartItem[]>(() =>{
      const saved = localStorage.getItem("app_cart")
      return saved ? JSON.parse(saved) : []
    })

const [isCartOpen , setIsCartOpen] = useState(false)

useEffect(() =>{
  localStorage.setItem("app_cart", JSON.stringify(items))
},[items])

const addToCart = (product : Product, quantity = 2) =>{
setItems((prev) =>{
  const existing = prev.find((item) => item.product.id === product.id )
  if(existing){
    return prev.map((item)=> (item.product.id === product.id ? {... item, quantity:item.quantity + quantity} : item))
  }
  return [...prev , {product, quantity}]
})

setIsCartOpen(true)
}


  const removeFromCart = (productId: string) =>{
    setItems((prev) => prev.filter((item) => item.product.id !== productId ))
  }

  const updateQuantity = (productId: string, quantity: number) => {
   if(quantity <= 0){
    removeFromCart(productId);
    return;
   }
  setItems((prev) => prev.map((item) =>(item.product.id === productId ? {... item, quantity} : item)))
  };

    const clearCart = () =>{
      setItems([])
      setIsCartOpen(false)
      
    }

const cartCount = items.reduce((sum ,item ) => sum + item.quantity, 0)


const cartTotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return <CartContext.Provider value={{
    items,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    cartCount, cartTotal, isCartOpen, setIsCartOpen
  }}>
    {children}
    
    </CartContext.Provider>;
}
 
export function UseCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within cartProvider");
  return context;
}
